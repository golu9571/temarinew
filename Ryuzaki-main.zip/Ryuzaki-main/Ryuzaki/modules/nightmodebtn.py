__mod_name__ = "NightMode"
__help__ = f"""
*Under Maintenance*
"""

